#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\flutter_windows_3.47.7-stable\flutter"
export "FLUTTER_APPLICATION_PATH=C:\Users\LENOVO\Polinema\Semester 5\Mobile\244107020142_mobile_course\06_week_6_authentication_security_fcm\Source_code"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=C:\Users\LENOVO\Polinema\Semester 5\Mobile\244107020142_mobile_course\06_week_6_authentication_security_fcm\Source_code\macos\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
